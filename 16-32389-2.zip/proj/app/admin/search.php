<?php 
  session_start();
  if(!isset($_SESSION['email']))
  {
    header("Location:../../index.php");
    }

    $con=mysqli_connect("localhost","root","","evarsity");
    if(!$con)
    {
        die("connection Error: ".mysqli_connect_error()."</br>");
    }

$sql="SELECT * FROM facultys where EXISTS(select * from login where facultys.facultyemail=login.email)" ;
$result=mysqli_query($con, $sql);

 ?>


<html>
<head>

  <script type="text/javascript">
function showUser()
{
  str=document.getElementById("searchf").value;
if (str=="")
  {
  document.getElementById("txtHint").innerHTML="";
  return;
  }
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","getuserF.php?q="+str,true);
xmlhttp.send();
}
</script>


</head>
<body>

<div id="txtHint"><b>Searched Person info will be displayed here.</b></div>
  <br> Search by E-mail: <input type="text" id="searchf" value="" >
  <button id="btn" onclick="showUser()">Search</button>   
 <br><br>
  <table style="width:70%" border="1">
  <tr>
    <th>ID</th>
    <th >Name</th>
    <th>E-mail</th>
       <th>Delete Faculty</th>
  </tr>

  <?php
    while($user=mysqli_fetch_assoc($result))
    {
        echo "<tr>";
        echo "<td>".$user['facultyId']."</td>";
        echo "<td>".$user['facultyname']."</td>";
        echo "<td><a href='facultyprofile.php?email=".$user['facultyemail']."'>".$user['facultyemail']."</a></td>"; 

             //passing get message through email to inbox
       echo "<td><a href='deletefaculty.php?email=".$user['facultyemail']."'>"."Delete"."</a></td>"; 

        //echo "<td><a href='message.php?email=".$user['email']."'>".$user['email']." </a></td>";           //passing get message through email to inbox
          //echo "<td><a href='friendprofile.php?email=".$user['email']."'>".$user['email']."</a></td>";          //passing get message through email to friend profile
        echo "</tr>";
      }
     ?>

 
  </table>
  <br>
<hr>


</body>
</html>