<?php

include_once("../../lib/db.php");
//$dir=dirname(__FILE__);
//echo $dir;
function getFaculty($facultyemail){
    $query="SELECT * FROM facultys WHERE facultyemail='$facultyemail'";
    $result=executeQuery($query);
    $user=null;
    if($result){
        $user=mysqli_fetch_assoc($result);
    }
    return $user;
}
function addCourses($course){

    $query="INSERT INTO courses(courseTitle,courseDes,coursePic,courseFeature,facultyName,courseNo,courseType,courselevel) VALUES('$course[courseTitle]','$course[courseDes]','$course[coursePic]','$course[courseFeature]','$course[facultyName]',$course[courseNo],$course[courseType],'$course[courselevel]')";
    return executeNonQuery($query);
}
function getCourse($course){
    $query="SELECT * FROM courses WHERE courseNo=$course";
    $result=executeQuery($query);
    $user=null;
    if($result){ 
        $user=mysqli_fetch_assoc($result);
    }
    return $user;
}
function addSyllabus($course){
    $query="INSERT INTO syllabus(courseMeetingTimeLecture,courseMeetingTimeReaction,prerequisites,descrip,assOrExams,facultyName,courseId) VALUES('$course[courseMeetingLecture]','$course[courseMeetingReaction]','$course[prerequisites]','$course[courseDes]','$course[assOrExams]','$course[instructor]',$course[courseid])";
    return executeNonQuery($query);
}
function addAssignment($course){
    $query="INSERT INTO assignment(courseId,facultyName,assignmentPdf) VALUES($course[courseid],'$course[instructor]','$course[target]')";
    return executeNonQuery($query);
}
function addNotes($course){
    $query="INSERT INTO lecturenotes(courseId,facultyName,lectureNote) VALUES($course[courseid],'$course[instructor]','$course[target]')";
    return executeNonQuery($query);
}
function addExams($course){
    $query="INSERT INTO exams(courseId,facultyName,questionPdf) VALUES($course[courseid],'$course[instructor]','$course[target]')";
    return executeNonQuery($query);
}

//function syllabusEdit($course){
  //  $query="UPDATE syllabus(syllabusId,courseMeetingTimeLecture,courseMeetingTimeReaction,prerequisites,descrip,assOrExams,facultyName,courseId) VALUES('$course[courseMeetingLecture]','$course[syllabusId]',$course[courseMeetingReaction]','$course[prerequisites]','$course[courseDes]','$course[assOrExams]','$course[instructor]',$course[courseid]) where syllabusId='$course[syllabusId]'";
    //return executeNonQuery($query);
//}
function syllabusEdit($course){
$query = "UPDATE syllabus SET syllabusId='$course[syllabusId]',courseMeetingTimeLecture='$course[courseMeetingLecture]',courseMeetingTimeReaction='$course[courseMeetingReaction]',prerequisites='$course[prerequisites]',descrip='$course[courseDes]',assOrExams='$course[assOrExams]',facultyName='$course[instructor]'
      WHERE courseId= '$course[courseid]'";
   return    executeNonQuery($query);
  
  }
function getMessage($email){
    $query="SELECT messageFrom,messageTo,messageDetail FROM messages where messageFrom='$email' or messageTo='$email'";
    $result=executeQuery($query);
    $message=array();
    if($result){
       for ($i=0; $row =mysqli_fetch_assoc($result) ; $i++) { 
           $message[$i]=$row;
       }
    }
    return $message;
}
function addMessage($user){
    $query="INSERT INTO messages(messageFrom,messageTo,messageDetail) VALUES('$user[email]','$user[to]','$user[detail]')";
    return executeNonQuery($query);
}
?>


