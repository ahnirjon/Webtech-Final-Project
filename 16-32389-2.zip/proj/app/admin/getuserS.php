<?php
ini_set('display_errors', 'On');
error_reporting(E_ALL);

$q=$_GET["q"];

$con = mysqli_connect('localhost', 'root', '');
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }

mysqli_select_db($con,"evarsity");

$sql="SELECT * FROM users where email like  '%$q%' ";



$result = mysqli_query($con,$sql);

mysqli_error($con);
echo "<table border='1'>
<tr>
<th>Student Id</th>
<th>Student Name</th>
<th>Student Email</th>

</tr>";

while($row = mysqli_fetch_array($result))
  {
  echo "<tr>";
        echo "<td>".$row['uid']."</td>";
        echo "<td>".$row['firstName']."</td>";
      echo "<td>".$row['email']."</td>";
      

  echo "</tr>";
  }
echo "</table>";

mysqli_close($con);
?>