<?php
ini_set('display_errors', 'On');
error_reporting(E_ALL);

$q=$_GET["q"];

$con = mysqli_connect('localhost', 'root', '');
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }

mysqli_select_db($con,"evarsity");

$sql="SELECT * FROM facultys where facultyemail like  '%$q%' ";



$result = mysqli_query($con,$sql);

mysqli_error($con);
echo "<table border='1'>
<tr>
<th>Faculty Id</th>
<th>Faculty Name</th>
<th>Faculty Email</th>

</tr>";

while($row = mysqli_fetch_array($result))
  {
  echo "<tr>";
        echo "<td>".$row['facultyId']."</td>";
        echo "<td>".$row['facultyname']."</td>";
        echo "<td><a href='facultyprofile.php?email=".$row['facultyemail']."'>".$row['facultyemail']."</a></td>"; 

  echo "</tr>";
  }
echo "</table>";

mysqli_close($con);
?>