<?php
ini_set('display_errors', 'On');
error_reporting(E_ALL);

$q=$_GET["q"];

$con = mysqli_connect('localhost', 'root', '');
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }

mysqli_select_db($con,"evarsity");

$sql="UPDATE courses SET approved=1 where courseId=".$q;



$result = mysqli_query($con,$sql);

mysqli_error($con);
echo "APPROVED";

mysqli_close($con);
?>