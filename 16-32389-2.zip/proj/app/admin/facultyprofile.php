<?php
  session_start();
$con=mysqli_connect("localhost","root","","evarsity"); //database connection
    if(!$con)
    {
        die("connection Error: ".mysqli_connect_error()."</br>");
    }
//$facultyId = $_GET['facultyId'];  
	  $facultyEmail=$_GET['email'];


//$email=$_SESSION['email'];
 $sql="SELECT * FROM facultys WHERE facultyemail = '$facultyEmail'";
 echo "<a href='logout.php'> logout</a> <br/><br/>";
 $result=mysqli_query($con, $sql);

 ?>
 
 <html>
 <head>
 	<title>My Profile</title>
 </head> 
 <body>

<h2 style="text-align:center">Profile Card</h2>
<table width="600" border="1" cellpadding="1" cellspacing="1">
		<tr>
			<th>Faculty ID</th>
			<th>Faculty Type</th>
			<th>Faculty Name</th>
			<th>Faculty Email</th>
			<th>Faculty Phone</th>
			
		</tr>
<?php
	while($user=mysqli_fetch_assoc($result))
			{	echo "<tr>";

				echo "<td>".$user['facultyId']."</td>";
				echo "<td>".$user['facultytype']."</td>";
				echo "<td>".$user['facultyname']."</td>";
				echo "<td>".$user['facultyemail']."</td>";
				echo "<td>".$user['facultyphn']."</td>";
			//	echo "<td><a href='message.php?email=".$user['email']."'>".$user['email']."</a></td>";

				echo "</tr>";
			}



 ?>
 
 </body>
 </html>