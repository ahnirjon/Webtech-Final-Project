<?php 

    $con=mysqli_connect("localhost","root","","evarsity");
    if(!$con)
    {
        die("connection Error: ".mysqli_connect_error()."</br>");
    }
    $email = $_GET['email'];

$sql="DELETE FROM login where email = '$email'";

echo $sql;
$result=mysqli_query($con, $sql);

mysqli_error($con);
header("location:search.php");
 ?>