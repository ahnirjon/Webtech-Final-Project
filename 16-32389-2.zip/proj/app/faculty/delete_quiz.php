<?php 

    $con=mysqli_connect("localhost","root","","evarsity");
    if(!$con)
    {
        die("connection Error: ".mysqli_connect_error()."</br>");
    }
    $examsId = $_GET['examsId'];
    $courseId = $_GET['courseId'];

$sql="DELETE FROM exams where examsId = ".$examsId;
$result=mysqli_query($con, $sql);
header("location:quizes.php?courseId=".$courseId);
 ?>