<?php 

    $con=mysqli_connect("localhost","root","","evarsity");
    if(!$con)
    {
        die("connection Error: ".mysqli_connect_error()."</br>");
    }
    $assignmentId = $_GET['assignmentId'];
     $courseId = $_GET['courseId'];

echo $assignmentId;
echo $courseId;

$sql="DELETE FROM assignment where assignmentId = ".$assignmentId;//bitch where did youge that asss id??
$result=mysqli_query($con, $sql);
header("location:assignments.php?"."courseId=".$courseId);
 ?>