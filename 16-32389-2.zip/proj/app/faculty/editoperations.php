<?php
$con=mysqli_connect("localhost","root","","evarsity");    //db connection
    if(!$con)
    {
        die("connection Error: ".mysqli_connect_error()."</br>");
    }

 		$courseTitle=$_POST['courseTitle'];
         $courseDescription=$_POST['courseDescription'];
        // $coursePic= $_POST['coursePic'];
          $courseFeature=$_POST['courseFeature'];
         $courseNumber= $_POST['courseNumber'];
         $courseLavel=$_POST['courseLavel'];
         $courseId=$_POST['courseId'];




  $sql = "UPDATE courses SET courseTitle='$courseTitle',courseDes='$courseDescription',courseFeature='$courseFeature',courseNo='$courseNumber',courselevel='$courseLavel'
      WHERE courseId= '$courseId'";
 //$result=mysqli_query($con, $sql);

 echo $sql;
 //header("location:view_course.php");
 if (mysqli_query($con, $sql)) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . mysqli_error($con);
}
echo "<script> alert('Information updated');</script>";
header("location:view_course.php");

 ?>