-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2019 at 07:51 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `evarsity`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignment`
--

CREATE TABLE `assignment` (
  `assignmentId` int(11) NOT NULL,
  `courseId` int(10) NOT NULL,
  `facultyName` varchar(30) NOT NULL,
  `assignmentPdf` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment`
--

INSERT INTO `assignment` (`assignmentId`, `courseId`, `facultyName`, `assignmentPdf`) VALUES
(40, 41, 'Debashish Kumar', 'assignments/Complex variable lec-7.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `courseId` int(11) NOT NULL,
  `courseTitle` varchar(100) NOT NULL,
  `courseDes` varchar(2000) NOT NULL,
  `coursePic` varchar(200) NOT NULL,
  `courseFeature` varchar(100) NOT NULL,
  `facultyName` varchar(30) NOT NULL,
  `courseNo` int(10) NOT NULL,
  `courseType` int(10) NOT NULL,
  `courselevel` varchar(20) NOT NULL,
  `approved` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`courseId`, `courseTitle`, `courseDes`, `coursePic`, `courseFeature`, `facultyName`, `courseNo`, `courseType`, `courselevel`, `approved`) VALUES
(41, 'Mathematics 1', 'The Mathematics Level 1 Subject Test assesses the knowledge youâ€™ve gained from three years of college-preparatory mathematics, including two years of algebra and one year of geometry. If youâ€™ve excelled in these courses, taking the test can support your high school grades, indicate an interest in pursuing math-based programs of study (science, technology, engineering, economics, etc.), and help you differentiate yourself in the admission process.', 'coursepic/math1.jpg', 'Complex Variable, Z-transform', 'Debashish Kumar', 301, 5, 'Undergraduate', 1);

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `examsId` int(11) NOT NULL,
  `courseId` int(10) NOT NULL,
  `facultyName` varchar(30) NOT NULL,
  `questionPdf` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exams`
--

INSERT INTO `exams` (`examsId`, `courseId`, `facultyName`, `questionPdf`) VALUES
(33, 41, 'Debashish Kumar', 'exams/M-3 Set A ( Midterm Fall 2016-17).pdf'),
(34, 41, 'Debashish Kumar', 'exams/M-3 SetA (Final_Fall_2016-17).pdf');

-- --------------------------------------------------------

--
-- Table structure for table `facultys`
--

CREATE TABLE `facultys` (
  `facultyId` int(11) NOT NULL,
  `facultytype` int(10) NOT NULL,
  `facultyname` varchar(30) NOT NULL,
  `facultyemail` varchar(30) NOT NULL,
  `facultypass` varchar(30) NOT NULL,
  `facultyphn` varchar(14) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `facultys`
--

INSERT INTO `facultys` (`facultyId`, `facultytype`, `facultyname`, `facultyemail`, `facultypass`, `facultyphn`) VALUES
(9, 3, 'Tahia Karim', 'tahiakarim@gmail.com', '1@', '+8801234567890'),
(10, 4, 'Shihab Sakib', 'ss@gmail.com', '1@', '+8801790909090'),
(11, 5, 'Debashish Kumar', 'dk@gmail.com', '1@', '+8801231231231'),
(12, 6, 'Mostafizur Rahman', 'mr@gmail.com', '1@', '+8801233211233');

-- --------------------------------------------------------

--
-- Table structure for table `lecturenotes`
--

CREATE TABLE `lecturenotes` (
  `lectureNotesId` int(11) NOT NULL,
  `courseId` int(10) NOT NULL,
  `facultyName` varchar(30) NOT NULL,
  `lectureNote` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lecturenotes`
--

INSERT INTO `lecturenotes` (`lectureNotesId`, `courseId`, `facultyName`, `lectureNote`) VALUES
(29, 41, 'Debashish Kumar', 'notes/Complex variable Lec-6.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `logid` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  `typeid` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`logid`, `email`, `password`, `typeid`) VALUES
(22, 'admin@gmail.com', '123', 1),
(43, 'dk@gmail.com', '1@', 5),
(45, 's@gmail.com', '1@', 2);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `messageId` int(11) NOT NULL,
  `messageFrom` varchar(30) NOT NULL,
  `messageTo` varchar(30) NOT NULL,
  `messageDetail` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`messageId`, `messageFrom`, `messageTo`, `messageDetail`) VALUES
(1, 's@gmail.com', 'dk@gmail.com', 'sir ami achi'),
(2, 'dk@gmail.com', 's@gmail.com', 'khub bhalo'),
(3, 's@gmail.com', 'dk@gmail.com', 'defence day!');

-- --------------------------------------------------------

--
-- Table structure for table `syllabus`
--

CREATE TABLE `syllabus` (
  `syllabusId` int(11) NOT NULL,
  `courseMeetingTimeLecture` varchar(200) NOT NULL,
  `courseMeetingTimeReaction` varchar(200) NOT NULL,
  `prerequisites` varchar(200) NOT NULL,
  `descrip` varchar(2000) NOT NULL,
  `assOrExams` varchar(100) NOT NULL,
  `facultyName` varchar(30) NOT NULL,
  `courseId` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `syllabus`
--

INSERT INTO `syllabus` (`syllabusId`, `courseMeetingTimeLecture`, `courseMeetingTimeReaction`, `prerequisites`, `descrip`, `assOrExams`, `facultyName`, `courseId`) VALUES
(18, '3 Hours', '1.5 Hours', 'None', 'This half course develops basic mathematical methods and will emphasise their applications to problems in economics, management and related areas.', '2/2', 'Debashish Kumar', 41);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `dob` varchar(30) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `phnNo` varchar(14) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `firstName`, `lastName`, `dob`, `gender`, `phnNo`, `email`, `password`) VALUES
(39, 'student', 'ami', '2019-04-10', 'Male', '+8806666677698', 's@gmail.com', '1@');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignment`
--
ALTER TABLE `assignment`
  ADD PRIMARY KEY (`assignmentId`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`courseId`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`examsId`);

--
-- Indexes for table `facultys`
--
ALTER TABLE `facultys`
  ADD PRIMARY KEY (`facultyId`);

--
-- Indexes for table `lecturenotes`
--
ALTER TABLE `lecturenotes`
  ADD PRIMARY KEY (`lectureNotesId`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`logid`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`messageId`);

--
-- Indexes for table `syllabus`
--
ALTER TABLE `syllabus`
  ADD PRIMARY KEY (`syllabusId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assignment`
--
ALTER TABLE `assignment`
  MODIFY `assignmentId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `courseId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `examsId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `facultys`
--
ALTER TABLE `facultys`
  MODIFY `facultyId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `lecturenotes`
--
ALTER TABLE `lecturenotes`
  MODIFY `lectureNotesId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `logid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `messageId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `syllabus`
--
ALTER TABLE `syllabus`
  MODIFY `syllabusId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
