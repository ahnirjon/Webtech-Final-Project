<?php 

    $con=mysqli_connect("localhost","root","","evarsity");
    if(!$con)
    {
        die("connection Error: ".mysqli_connect_error()."</br>");
    }
    $courseId = $_GET['courseId'];

$sql="DELETE FROM courses where courseId = ".$courseId;
$result=mysqli_query($con, $sql);
header("location:view_course.php");
 ?>