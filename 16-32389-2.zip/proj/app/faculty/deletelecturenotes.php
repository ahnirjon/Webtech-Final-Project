  <?php 

    $con=mysqli_connect("localhost","root","","evarsity");
    if(!$con)
    {
        die("connection Error: ".mysqli_connect_error()."</br>");
    }
    $lectureNotesId = $_GET['lectureNotesId'];
    $courseId = $_GET['courseId'];

$sql="DELETE FROM lecturenotes where lectureNotesId = ".$lectureNotesId;
$result=mysqli_query($con, $sql);
header("location:lecturenotes.php?courseId=".$courseId);
 ?>